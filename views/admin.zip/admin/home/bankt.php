<?php

session_start();
$_SESSION["broker"]="25";
  include("homepath1.php");
  
 ?>