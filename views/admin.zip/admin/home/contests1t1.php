<?php

session_start();
$_SESSION["broker"]="2";
  include("homepath1.php");
  
 ?>