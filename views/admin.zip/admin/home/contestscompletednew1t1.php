<?php

session_start();
$_SESSION["broker"]="19";
  include("homepath1.php");
  
 ?>