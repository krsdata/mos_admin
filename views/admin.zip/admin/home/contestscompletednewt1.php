<?php

session_start();
$_SESSION["broker"]="18";
  include("homepath1.php");
  
 ?>