<?php

session_start();
$_SESSION["broker"]="16";
  include("homepath1.php");
  
 ?>