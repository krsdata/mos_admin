
<?php

session_start();
$_SESSION["broker"]="23";
  include("homepath1.php");
  
 ?>