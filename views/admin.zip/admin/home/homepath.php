<?php
header("Location: ../../admin");
?>