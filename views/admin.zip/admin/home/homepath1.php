<?php
header("Location: ../home");
?>