<?php

session_start();
$_SESSION["broker"]="1";
$_SESSION["val1"]=0;
  include("homepath1.php");
  
 ?>