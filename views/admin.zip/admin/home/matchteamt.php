<?php

session_start();
$_SESSION["broker"]="3";
  include("homepath1.php");
  
 ?>