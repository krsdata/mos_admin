<?php

session_start();
$_SESSION["broker"]="21";
  include("homepath1.php");
  
 ?>