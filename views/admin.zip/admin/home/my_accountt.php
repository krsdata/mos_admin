<?php

session_start();
$_SESSION["broker"]="14";
  include("homepath1.php");
  
 ?>