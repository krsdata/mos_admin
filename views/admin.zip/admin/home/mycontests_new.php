<?php
 include("../../../db/config.php");

if(isset($_SESSION["val1"]))
{
$_SESSION["val1"]=0;

}

$ty=rand(101,1000);
 $_SESSION["mid"]=$ty;

?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  
  <!-- CSS Files -->
  <link href="./assets/css/material-kit.css?v=2.0.3" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="./assets/demo/demo.css" rel="stylesheet" />
 <link href="./assets/css/tab.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
        <style>

.header5 {
    background-color: #3b5998;
    color: white;
    padding: 1%;
     text-align: center;
     width: 30%;
     font-size: 20px;
     
    position: absolute;
   top: 20%;
    left: 33%;
       
}


        body
        {
            background: url(./assets/img/bg.jpg)no-repeat;
            background-color: white;
            background-size: 115%;
            background-position-x: 35%;
        }
    .navbar
        {
            width:555px;
            margin:auto;
        }
    .navbar-top
    {
        background-color:#3b5998 !important;
        height: 90px;
        font-size: 30px;
    }
    .navbar-brand
       {
           margin:auto;
           color: white !important;
           font-weight:bolder !important;
           font-size: 25px !important;
       }
    .middle
    {
        width: 555px;
    height: 89vh;
    margin: auto;
    margin-top: 70px;
  background-color: white;
    padding: 15px;
    overflow: auto;
    }
    .navbar-bottom
    {
background-color: #3b5998;
        padding: 10px;
        height: 70px;
      font-size: 14px;
  color: white;
    }
    .navbar-bottom .material-icons
    {
        margin-left: 8px;
        font-size: 18px;
        color: white;
        transition: .5s;
        cursor:pointer;
    }
    .navicon
    {
        width: 50px;
        height: 30px;
        margin-left: auto;
        margin-right: auto;
    }


/* Match cards starts */

.card
{
  margin-bottom: 0px;
    margin-top: 10px;
}
.left
{     height: 100px;
      border-radius: 3px;
    display: inline;
    margin-right: 8px;
    margin-top: 0px;
}

.left1
{     
      border-radius: 3px;
    display: inline;
    margin-right: 8px;
    margin-top: 0px;
}

 
.right
{
  height: 100px;
    border-radius: 3px;
    display: inline;
    margin-left: 2px;
    margin-right: 0px;
    margin-top: 0px;
}

.right1
{
 
    border-radius: 3px;
    display: inline;
    margin-left: 2px;
    margin-right: 0px;
    margin-top: 0px;
}

.font
  {
    font-size:15.5px;
    font-weight:bold;
  }
  small
  {
    color:black;
    font-weight:bold;
  }
  .main
  { 
    padding: 15px;
  height: 100vh;
  overflow: auto;
  
  }

  @media only screen and (min-width: 768px) {
   .card
   {
     width:500px;
   }
   .left
  {
    height: 100px;
    border-radius: 5px;
    display: inline;
    margin-right: 40px;
    margin-top: 0px;
  }
   .left1
  {
 
    border-radius: 5px;
    display: inline;
    margin-right: 40px;
    margin-top: 0px;
  }
  .right
  {
    height: 100px;
    border-radius: 5px;
    display: inline;
    margin-left: 40px;
    margin-right: 0px;
    margin-top: 0px;
  }
  .right1
  {

    border-radius: 5px;
    display: inline;
    margin-left: 40px;
    margin-right: 0px;
    margin-top: 0px;
  }
   .main
  {
  
    padding: 15px;
    width:555px;
  height: 92vh;
  overflow: auto;
 
  }
  .mar
  {
    margin: -15px;
    width: 555px;
    color: white;
    font-weight: bold;
    background: #3582ff;
  }
}
.mar
  {
    margin: -15px;
    width: 109%;
    border-radius: 0px;
    background: #3582ff;
  }
  
/* Match cards ends */


       /* media query starts for bellow 600px*/
@media only screen and (max-width: 600px)
       {
        body
        {
            background: url(./assets/img/bg.jpg)no-repeat;
           background-color:#0078d7;
            background-position-x: 45%;
        }
        .navbar
        {
            width:100%;
            margin:auto;
           
        }
        .middle
    {
        width:100%;
        height:auto;
        margin:auto;
        margin-top:70px;
        background-color:#cccccccc;
    }
    .navbar-bottom .material-icons
    {
        margin-left: 8px;
        font-size: 35px;

    }
    .navicon
    {
        width: 50px;
        height: 30px;
        margin-left: auto;
        margin-right: auto;
    }
       }
       /* media query ends*/
.navbar-bottom .material-icons:hover
{
    color:#0078d7;
    transition: .5s;
}

         </style>

    </head>
    <body>
    <div class="navbar navbar-top fixed-top">
<div class="header5">
My Contests</div>
</div>

      <div class="middle">

<br />
<input id="tab1" type="radio" name="tabs" checked>
  <label for="tab1" style=" width: 32%">Fixtures</label>
    
  <input id="tab2" type="radio" name="tabs">
  <label for="tab2" style=" width: 33%">Live</label>
    
  <input id="tab3" type="radio" name="tabs">
  <label for="tab3" style=" width: 32%">Results</label>

 <section id="content1">

<?php



                        //$qry='SELECT matches.matchid,matches.time,matches.match_type, team1.team_name AS team1, team1.image AS team1_image, team2.team_name AS team2, team2.image AS team2_image FROM matches JOIN team team1 ON matches.t1= team1.id LEFT OUTER JOIN team team2 ON matches.t2=team2.id WHERE matches.status=1 order by matches.time';						$qry='SELECT * FROM API_matches WHERE `mat_status` = "1" order by `mat_startdate`';
                        $result1 = mysqli_query($conn,$qry);
                        $r1 = mysqli_num_rows($result1);

                        if($r1>0)
                        {
                          while ($rows1 = mysqli_fetch_array($result1)) {
                            $mat_comp_id = $rows1['mat_comp_id'];							$t1 = $rows1['mat_team1_id'];							$t2 = $rows1['mat_team2_id'];														$sql0 = "SELECT comp_title FROM API_competition WHERE `comp_id` = '$mat_comp_id'";							$result0 = mysqli_query($conn,$sql0);							$row0 = mysqli_fetch_assoc($result0);							$comp_title = $row0['comp_title'];														$sql1 = "SELECT team_logo_url FROM API_team WHERE `team_id` = '$t1'";							$r1 = mysqli_query($conn,$sql1);							$row1 = mysqli_fetch_assoc($r1);							$sql2 = "SELECT team_logo_url FROM API_team WHERE `team_id` = '$t2'";							$r2 = mysqli_query($conn,$sql2);							$row2 = mysqli_fetch_assoc($r2);
                            $t1_image=$row1['team_logo_url'];
                            $t2_image=$row2['team_logo_url'];

                            $matchtype=$rows1['mat_sub_title'];							$mat_short_title=$rows1['mat_short_title'];
                            $match3=$rows1['mat_id'];
                            $finaldate=$rows1['mat_startdate'];

$ty1=((intval($match3)+$ty)*3)-$ty;
       
                            echo' <a href="contests_new.php?trans1='.$match3.'"><div class="card mx-auto">
                                <div class="row container" style="padding:0px; width: fit-content;margin-left: auto;
                                margin-right: auto;">
                                  <div style="display:inline;">
                                       <br />
                                        <img src="'.$t1_image.'" class="left1" width="60" height="60" >
                                      </div>
                                      <div style="width: 250px;">
                                     <p class="text-center"><br />'.$mat_short_title.'<br />'.$matchtype.'<br />'.$comp_title.'
<br /><i style="font-size: 12px;" class="material-icons">alarm</i><i id="'.$match3.'"></i>

<script>
// Set the date were counting down to
 var countDownDate'.$match3.'= new Date("'.$finaldate.'").getTime();

// Update the count down every 1 second
var x'.$match3.' = setInterval(function() {

    // Get todays date and time
    var now'.$match3.' = new Date().getTime();
    
    // Find the distance between now an the count down date
    var distance'.$match3.' = countDownDate'.$match3.' - now'.$match3.';
    
    // Time calculations for days, hours, minutes and seconds
    var days'.$match3.' = Math.floor(distance'.$match3.' / (1000 * 60 * 60 * 24));
    var hours'.$match3.' = Math.floor((distance'.$match3.' % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes'.$match3.' = Math.floor((distance'.$match3.' % (1000 * 60 * 60)) / (1000 * 60));
    var seconds'.$match3.' = Math.floor((distance'.$match3.' % (1000 * 60)) / 1000);
    
    // Output the result in an element with id="demo"
    document.getElementById("'.$match3.'").innerHTML = days'.$match3.' + "d:" + hours'.$match3.' + "h:"
    + minutes'.$match3.' + "m:" + seconds'.$match3.' + "s";
    
    // If the count down is over, write some text 
    if (distance'.$match3.' < 0) {
        clearInterval(x'.$match3.');
        document.getElementById("'.$match3.'").innerHTML = "Completed";



    }
}, 1000);
</script> 

                                    </p>
                                      </div>
                                      <div style="display:inline;">
                                      <br />
                                      <img src="'.$t2_image.'"  class="right1" width="60" height="60" >
                                    </div>
                                 </div>
                              </div></a> ';
                          }
                            
                        }
                        else
                        {
                            echo ' <div class="card mx-auto">
                            <div class="row container" style="padding:5px; width: 100%;">
                              
                                  <div style="display:inline;width:100%">
                                 <p class="text-center"><span class="font">No Matches Held</span></p>
                                  </div>
                                     </div>
                          </div> ';
                        }
                        
                        ?>



<br /><br /><br />

</section>


<section id="content2">

<?php



                        //$qry='SELECT matches.matchid,matches.time,matches.match_type, team1.team_name AS team1, team1.image AS team1_image, team2.team_name AS team2, team2.image AS team2_image FROM matches JOIN team team1 ON matches.t1= team1.id LEFT OUTER JOIN team team2 ON matches.t2=team2.id WHERE matches.status=2 order by matches.time';						$qry='SELECT * FROM API_matches WHERE `mat_status` = "3" order by `mat_startdate`';
                        $result1 = mysqli_query($conn,$qry);
                        $rows1 = mysqli_num_rows($result1);

                        if($rows1>0)
                        {
                          while ($rows1 = mysqli_fetch_array($result1)) {
                            $t1 = $rows1['mat_team1_id'];							$t2 = $rows1['mat_team2_id'];							$sql1 = "SELECT team_logo_url FROM API_team WHERE `team_id` = '$t1'";							$r1 = mysqli_query($conn,$sql1);							$row1 = mysqli_fetch_assoc($r1);							$sql2 = "SELECT team_logo_url FROM API_team WHERE `team_id` = '$t2'";							$r2 = mysqli_query($conn,$sql2);							$row2 = mysqli_fetch_assoc($r2);                            $t1_image=$row1['team_logo_url'];                            $t2_image=$row2['team_logo_url'];                            $matchtype=$rows1['mat_sub_title'];							$mat_short_title=$rows1['mat_short_title'];                            $match3=$rows1['mat_id'];                            $finaldate=$rows1['mat_startdate'];

$ty1=((intval($match3)+$ty)*3)-$ty;
       
                            echo' <a href="contests1_new.php?trans1='.$match3.'"><div class="card mx-auto">
                                <div class="row container" style="padding:0px; width: fit-content;margin-left: auto;
                                margin-right: auto;">
                                  <div style="display:inline;">
                                       <br />
                                        <img src="'.$t1_image.'" class="left1" width="60" height="60" >
                                      </div>
                                      <div style="width: 250px;">
                                     <p class="text-center"><br />'.$mat_short_title.'&nbsp;&nbsp;'.$matchtype.'
<br /><i style="font-size: 12px;" class="material-icons">alarm</i>Live</i></p>

<script>
// Set the date were counting down to
 var countDownDate'.$match3.'= new Date("'.$finaldate.'").getTime();

// Update the count down every 1 second
var x'.$match3.' = setInterval(function() {

    // Get todays date and time
    var now'.$match3.' = new Date().getTime();
    
    // Find the distance between now an the count down date
    var distance'.$match3.' = countDownDate'.$match3.' - now'.$match3.';
    
    // Time calculations for days, hours, minutes and seconds
    var days'.$match3.' = Math.floor(distance'.$match3.' / (1000 * 60 * 60 * 24));
    var hours'.$match3.' = Math.floor((distance'.$match3.' % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes'.$match3.' = Math.floor((distance'.$match3.' % (1000 * 60 * 60)) / (1000 * 60));
    var seconds'.$match3.' = Math.floor((distance'.$match3.' % (1000 * 60)) / 1000);
    
    // Output the result in an element with id="demo"
    document.getElementById("'.$match3.'").innerHTML = days'.$match3.' + "d:" + hours'.$match3.' + "h:"
    + minutes'.$match3.' + "m:" + seconds'.$match3.' + "s";
    
    // If the count down is over, write some text 
    if (distance'.$match3.' < 0) {
        clearInterval(x'.$match3.');
        document.getElementById("'.$match3.'").innerHTML = "Completed";



    }
}, 1000);
</script> 


                                      </div>
                                      <div style="display:inline;">
                                      <br />
                                      <img src="'.$t2_image.'"  class="right1" width="60" height="60" >
                                    </div>
                                 </div>
                              </div></a> ';
                          }
                            
                        }
                        else
                        {
                            echo ' <div class="card mx-auto">
                            <div class="row container" style="padding:5px; width: 100%;">
                              
                                  <div style="display:inline;width:100%">
                                 <p class="text-center"><span class="font">No Matches Held</span></p>
                                  </div>
                                     </div>
                          </div> ';
                        }
                        
                        ?>



<br /><br /><br />


</section>


<section id="content3">

<?php



                        //$qry='SELECT matches.matchid,matches.time,matches.status2,matches.match_type, team1.team_name AS team1, team1.image AS team1_image, team2.team_name AS team2, team2.image AS team2_image FROM matches JOIN team team1 ON matches.t1= team1.id LEFT OUTER JOIN team team2 ON matches.t2=team2.id WHERE matches.status=3 order by matches.time desc';						$qry='SELECT * FROM API_matches WHERE `mat_status` = "3" order by `mat_startdate`';						
                        $result1 = mysqli_query($conn,$qry);
                        $rows1 = mysqli_num_rows($result1);
              
                        if($rows1>0)
                        {
                          while ($rows1 = mysqli_fetch_array($result1)) {
                            $t1 = $rows1['mat_team1_id'];							$t2 = $rows1['mat_team2_id'];							$sql1 = "SELECT team_logo_url FROM API_team WHERE `team_id` = '$t1'";							$r1 = mysqli_query($conn,$sql1);							$row1 = mysqli_fetch_assoc($r1);							$sql2 = "SELECT team_logo_url FROM API_team WHERE `team_id` = '$t2'";							$r2 = mysqli_query($conn,$sql2);							$row2 = mysqli_fetch_assoc($r2);                            $t1_image=$row1['team_logo_url'];                            $t2_image=$row2['team_logo_url'];                            $matchtype=$rows1['mat_sub_title'];							$mat_short_title=$rows1['mat_short_title'];                            $match3=$rows1['mat_id'];                            $finaldate=$rows1['mat_startdate'];							$cancelled=$rows1['mat_status'];

$ty1=((intval($match3)+$ty)*3)-$ty;
       
                            echo' <a href="contests2_new.php?trans1='.$match3.'"><div class="card mx-auto">
                                <div class="row container" style="padding:0px; width: fit-content;margin-left: auto;
                                margin-right: auto;">
                                  <div style="display:inline;">
                                       <br />
                                        <img src="'.$t1_image.'" class="left1" width="60" height="60" >
                                      </div>
                                      <div style="width: 250px;">
                                     <p class="text-center"><br />'.$mat_short_title.'&nbsp;&nbsp;'.$matchtype.'
<br /><i style="font-size: 12px;" class="material-icons">alarm</i>
';

if($cancelled==4)
{
echo 'Cancelled';
}
else
{
echo 'Completed';
}

echo '

</i></p>

<script>
// Set the date were counting down to
 var countDownDate'.$match3.'= new Date("'.$finaldate.'").getTime();

// Update the count down every 1 second
var x'.$match3.' = setInterval(function() {

    // Get todays date and time
    var now'.$match3.' = new Date().getTime();
    
    // Find the distance between now an the count down date
    var distance'.$match3.' = countDownDate'.$match3.' - now'.$match3.';
    
    // Time calculations for days, hours, minutes and seconds
    var days'.$match3.' = Math.floor(distance'.$match3.' / (1000 * 60 * 60 * 24));
    var hours'.$match3.' = Math.floor((distance'.$match3.' % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes'.$match3.' = Math.floor((distance'.$match3.' % (1000 * 60 * 60)) / (1000 * 60));
    var seconds'.$match3.' = Math.floor((distance'.$match3.' % (1000 * 60)) / 1000);
    
    // Output the result in an element with id="demo"
    document.getElementById("'.$match3.'").innerHTML = days'.$match3.' + "d:" + hours'.$match3.' + "h:"
    + minutes'.$match3.' + "m:" + seconds'.$match3.' + "s";
    
    // If the count down is over, write some text 
    if (distance'.$match3.' < 0) {
        clearInterval(x'.$match3.');
        document.getElementById("'.$match3.'").innerHTML = "Completed";



    }
}, 1000);
</script> 

                                      </div>
                                      <div style="display:inline;">
                                      <br />
                                      <img src="'.$t2_image.'"  class="right1" width="60" height="60" >
                                    </div>
                                 </div>
                              </div></a> ';
                          }
                            
                        }
                        else
                        {
                            echo ' <div class="card mx-auto">
                            <div class="row container" style="padding:5px; width: 100%;">
                              
                                  <div style="display:inline;width:100%">
                                 <p class="text-center"><span class="font">No Matches Held</span></p>
                                  </div>
                                     </div>
                          </div> ';
                        }
                        mysqli_close($conn);
                        ?>



<br /><br /><br />



</section>



      </div>
      <?php
   
echo '
<div class="navbar navbar-bottom fixed-bottom">
     

      <div class="navicon">
      <a href="logout.php" style="color:white;"><i class="material-icons">account_circle</i>
<br />
&nbsp; Logout</a>
      </div>
   

     <div>';
      ?>
      
      
        <script src="" async defer></script>
    </body>
</html>