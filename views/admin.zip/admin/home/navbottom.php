<?php

echo '
<style>
 .navbar-bottom
    {
background-color: #3b5998;
        padding: 10px;
        height: 70px;
      font-size: 14px;
  color: white;
    }
    .navbar-bottom .material-icons
    {
        margin-left: 8px;
        font-size: 18px;
        color: white;
        transition: .5s;
        cursor:pointer;
    }

</style>
<div class="navbar navbar-bottom fixed-bottom">
     
<div class="navicon">
<center>
     <a href="homet.php" style="color:white;"><i class="material-icons">home</i>
<br />
    Home</a>
      </div>
      <div class="navicon">
<center>
      <a href="mycontestst.php" style="color:white;"><i class="material-icons">star</i>
<br />
     mycontests</a>
</center>
      </div>
      <div class="navicon">
      <a href="my_accountt.php" style="color:white;"><i class="material-icons">account_circle</i>
<br />
&nbsp; me  </a>
      </div>
      <div class="navicon">
      <a href="moret.php" style="color:white;"><i class="material-icons">more</i>
<br />
    more</a>
      </div>
</center>
     <div>';

?>