<?php
if(isset($_SESSION['name']))
{
echo'

<div class="navbar navbar-bottom fixed-bottom">
      <div class="navicon">
     <a href="home.php"><i class="material-icons">home</i></a>
      </div>
      <div class="navicon">
      <a href="mycontests.php"><i class="material-icons">star</i></a>
      </div>
      <div class="navicon">
      <a href="my_account.php"><i class="material-icons">account_circle</i></a>
      </div>
        <div>

';
}
?>




