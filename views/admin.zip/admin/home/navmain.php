<div class="navbar navbar-top fixed-top">
<div class="navbar-brand">
Cricket
</div>
</div>