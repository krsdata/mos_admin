<?php

session_start();
$_SESSION["broker"]="12";
  include("homepath1.php");
  
 ?>