<?php

session_start();
$_SESSION["broker"]="4";
  include("homepath1.php");
  
 ?>