<?php

session_start();
$_SESSION["broker"]="24";
  include("homepath1.php");
  
 ?>